# Enable Flask's debugging features. Should be False in production
DEBUG = False

# Enable protection against Cross-site Request Forgery (CSRF)
CSRF_ENABLED = True
